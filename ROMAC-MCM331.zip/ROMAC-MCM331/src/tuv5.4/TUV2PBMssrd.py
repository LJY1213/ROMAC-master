import pandas as pd
import os
tuv2mcm = pd.read_csv('TUV2MCM.csv')
month = os.getenv('MONTH')
day   = os.getenv('DAY')

today         = os.getenv("DATE")
data_dir      = os.getenv("DATA_DIR")
metoinputfile = os.getenv("INPUT_FILE")

filename = 'J'+month.zfill(2)+day.zfill(2)+'.txt' 
J_values = pd.DataFrame()
k = 0
z = 0
u = 0
with open(filename, 'r') as file_to_read:
    while True:
        lines = file_to_read.readline() 
        if lines.split()[0] == 'time,':
            z = 1
        else:
            z = 0
        if (u == 1) & (lines[0] != '-'):
            J_values[k] = pd.to_numeric(lines.split())
            k+=1
        if lines[0] == '-':
            break
            pass
        u = u+z

metodata = pd.read_excel(data_dir+"/"+metoinputfile,sheet_name = "meto")
for t in range(24):

    ssrd  = metodata[metodata["时间"] == today+" "+str(t).zfill(2)].ssrd.values[0]
    ssrdc = metodata[metodata["时间"] == today+" "+str(t).zfill(2)].ssrdc.values[0]

    if (ssrdc > 0.0):
        jrate = ssrd/ssrdc
    else:
        jrate = 1.0

    output = pd.DataFrame()
    output[0] = tuv2mcm.MCM331
    k = 0
    for i in tuv2mcm.TUV:
        
        jmod = J_values.iloc[i+1,t]*jrate
        #jmod = J_values.iloc[i+1,t]
        output.loc[k,1] = "%E"%jmod
        
        k+=1
    output.to_csv('Jvalue_'+str(t).zfill(2),header=False,index = False,sep = ' ')
