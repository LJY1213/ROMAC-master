import pandas as pd
import os
tuv2mcm = pd.read_csv('TUV2MCM.csv')
month = os.getenv('MONTH')
day   = os.getenv('DAY')

filename = 'J'+month.zfill(2)+day.zfill(2)+'.txt' 
J_values = pd.DataFrame()
k = 0
z = 0
u = 0
with open(filename, 'r') as file_to_read:
    while True:
        lines = file_to_read.readline() 
        if lines.split()[0] == 'time,':
            z = 1
        else:
            z = 0
        if (u == 1) & (lines[0] != '-'):
            J_values[k] = pd.to_numeric(lines.split())
            k+=1
        if lines[0] == '-':
            break
            pass
        u = u+z

for t in range(24):
    output = pd.DataFrame()
    output[0] = tuv2mcm.MCM331
    k = 0
    for i in tuv2mcm.TUV:
        output.loc[k,1] = "%E"%J_values.iloc[i+1,t]
        k+=1
    output.to_csv('Jvalue_'+str(t).zfill(2),header=False,index = False,sep = ' ')