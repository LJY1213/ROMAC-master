import os
import subprocess
import datetime
import pandas as pd
import numpy as np

strstime     = "2023-09-24" #开始日期
stretime     = "2023-09-25" #结束日期

starttime = [int(strstime.split("-")[0]),int(strstime.split("-")[1]),int(strstime.split("-")[2])]
endtime = [int(stretime.split("-")[0]),int(stretime.split("-")[1]),int(stretime.split("-")[2])]

site = "LC"
lon  = "123.4336"
lat  = "41.8150"

LON = str(lon)
LAT = str(lat)
OBMHOME        = "/media/ljy2/D1/ROMAC-MCM331/src/"  #ROMAC src文件夹目录
DATA_DIR       = OBMHOME+"/UserData/"             #输入文件路径
INPUT_FILE     = "ROMACINPUT20230924.fix2.xlsx" #输入文件
#outputdir       = nml.readline().replace("\n","")

AVOC_RATE  = "1.0"
BVOC_RATE  = "1.0"
NOx_RATE   = "1.0"
CO_RATE    = "1.0"
HRSOLVER   = "VSVR"
OTHRATEMOD = "A"
TUVTOOL    = "T"           #调用TUV工具计算光解速率, T开启，F关闭
TUVHOME    = OBMHOME+"/tuv5.4/V5.4"
EC_RATE    = "1.0"         #光解速率计算, 太阳辐射关闭时使用，适用于使用自然光的室外烟雾箱实验, 晴空清洁大气光解速率EC_RATE = 1.0
CHAMBER_MOD = "F"          #黑光灯模式,F关闭, JNUchamber JNO2 = 0.360/min, EC_RATE = 0.6015
SOLAR_BASE  = "F"          #基于太阳辐射计算光解速率, T开启, F关闭, 建议使用OBM模式时开启
SOLAR_CLSKY = "100"        #晴空清洁大气太阳辐射日均值(W/m2) GYQ:150 HGS:500 HGS201912:6200 
JVALUE_INP  = "F"          #输入光解速率观测值

PHOT_DIAG     = "T"         #光化学诊断工具，T开启，F关闭
CHEM_DIAG     = "T"         #化学过程诊断工具，T开启，F关闭
OFP_OUTPUT    = "T"         #臭氧生成潜势，P(O3-NO)
OUTPUT_UNIT   = "ppbv"   #浓度单位，ppbv,ppmv,molc
CONC_INP_UNIT = "ppbv"   #数据导入浓度单位，ppbv, molc
CONCINP_TYPE  = "other"  #物种浓度输入方案 Linear 内置插值法
DILUTE        = "T"

# Dry depostion
DRYDEPV       = "F"     #T or F
CANOPIESTYPE  = "dry"   #dry or wet


TIME_TYPE     = "LOCAL" #时间类型，UTC或当地时间
#setenv TIME_TYPE    UTC   #时间类型，UTC或当地时间



os.chdir(OBMHOME)

os.environ["OBMHOME"] = OBMHOME
os.environ["DATA_DIR"] = DATA_DIR
os.environ["INPUT_FILE"] = INPUT_FILE 
os.environ["AVOC_RATE"] = AVOC_RATE
os.environ["BVOC_RATE"] = BVOC_RATE
os.environ["NOx_RATE"] = NOx_RATE
os.environ["CO_RATE"]  = CO_RATE
os.environ["HRSOLVER"] = HRSOLVER
os.environ["OTHRATEMOD"] = OTHRATEMOD
os.environ["TUVTOOL"] = TUVTOOL
os.environ["TUVHOME"] = TUVHOME
os.environ["EC_RATE"] = EC_RATE
os.environ["CHAMBER_MOD"] = CHAMBER_MOD
os.environ["SOLAR_BASE"] = SOLAR_BASE
os.environ["SOLAR_CLSKY"] = SOLAR_CLSKY
os.environ["JVALUE_INP"] = JVALUE_INP

os.environ["PHOT_DIAG"]  = PHOT_DIAG
os.environ["CHEM_DIAG"]  = CHEM_DIAG
os.environ["OFP_OUTPUT"]    = OFP_OUTPUT
os.environ["OUTPUT_UNIT"] = OUTPUT_UNIT
os.environ["CONC_INP_UNIT"] = CONC_INP_UNIT
os.environ["CONCINP_TYPE"]  = CONCINP_TYPE
os.environ["DILUTE"]        = DILUTE

# Dry depostion
os.environ["DRYDEPV"]       = DRYDEPV
os.environ["CANOPIESTYPE"]  = CANOPIESTYPE

os.environ["TIME_TYPE"]     = TIME_TYPE
#setenv TIME_TYPE    UTC   #时间类型，UTC或当地时间

os.environ["LAT"] = LAT
os.environ["LON"] = LON

#subprocess.call(["python3","./tools/dailycyc.py"])
#INPUT_FILE = INPUT_FILE.split(".")[0]+".dailycyc.xlsx"
#subprocess.call(["python3","./tools/datafix2.py"])
#INPUT_FILE = INPUT_FILE.split(".")[0]+".fix2.xlsx"
os.environ["INPUT_FILE"] = INPUT_FILE 

os.system("rm "+OBMHOME+"/model_data/initconc.txt")
os.system("rm "+OBMHOME+"/model_data/CGRIDCONC_ppbv.txt")
os.system("cp ./model_data/zeros.txt ./model_data/initconc.txt")

def set_daterange(x,y):
    begin = datetime.date(x[0],x[1],x[2])
    end = datetime.date(y[0],y[1],y[2])
    delta = datetime.timedelta(days=1)
    begin = begin
    end   = end
    d = begin
    date_set = pd.Series([],dtype='str')
    i = 1
    while d <= end:
        date_set[i] = d.strftime("%Y-%m-%d")
        d += delta
        i +=1
    return(date_set)
    
datelist = set_daterange(starttime,endtime)

for date in datelist:
    os.environ["DATE"]  = date
    os.environ["YEAR"]  = date.split("-")[0]
    os.environ["MONTH"] = date.split("-")[1]
    os.environ["DAY"] = date.split("-")[2]
    os.system("cp "+OBMHOME+"/model_data/CGRIDCONC_ppbv.txt "+OBMHOME+"/model_data/initconc.txt")

    if (TUVTOOL == 'T'):
	    subprocess.call(["csh",TUVHOME+"/../run_tuv.pbm.csh"])
    else:
        pass

    subprocess.call(["python3","./calcJulday.py"])
    subprocess.call(["python3","./PREP.py"])

    subprocess.run("./ROMAC.exe")
    os.system("rm "+OBMHOME+"/model_data/CONCINP*")
    os.system("rm "+OBMHOME+"/model_data/PRES_input.txt")
    os.system("rm "+OBMHOME+"/model_data/TEMP_input.txt")
    os.system("rm "+OBMHOME+"/model_data/RH_input.txt")
    os.system("rm "+OBMHOME+"/model_data/Jvalue*")
    os.system("rm "+OBMHOME+"/model_data/EMIS_*")
    os.system("rm "+OBMHOME+"/model_data/OTHRATE_*")
    #os.system("rm "+OBMHOME+"/output/CHEM*")
    #os.system("rm "+OBMHOME+"/output/PROD*")
    #os.system("rm "+OBMHOME+"/output/LOSS*")
    os.system("rm "+OBMHOME+"/part_output/*")
    #os.system("rm "+OBMHOME+"/output/CALL*")
exit()
