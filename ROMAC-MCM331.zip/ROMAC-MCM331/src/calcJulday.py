import pandas as pd
import numpy as np
import os
import datetime


datei = os.getenv("DATE")
lat = os.getenv("LAT")
lon = os.getenv("LON")
#ec_rate = os.getenv("EC_RATE")
ifsolarbase = os.getenv("SOLAR_BASE")
#model_unc = os.getenv("MODEL_UNC")
#obs_unc = os.getenv("OBS_UNC")
def set_daterange(x,y):
    begin = datetime.date(x[0],x[1],x[2])
    end = datetime.date(y[0],y[1],y[2])
    d = begin
    delta = datetime.timedelta(days=1)
    date_set = pd.Series([],dtype='str')
    i = 1
    while d <= end:
        date_set[i] = d.strftime("%Y-%m-%d")
        d += delta
        i +=1
    return(date_set)

year = int(datei[0:4])
alldate = set_daterange([year,1,1],[year,12,31])
julday = np.where(alldate == datei)[0][0]+1
f = open("./Julday.txt","w")
f.writelines(str(julday)+".00")
f.writelines("   "+str(lat))
f.writelines("   "+str(lon))

if ifsolarbase == "T":
    cleanskysolar = float(os.getenv("SOLAR_CLSKY"))
    data_wd = os.getenv("DATA_DIR")
    input_file = os.getenv("INPUT_FILE")
    solardata = pd.read_excel(data_wd+'/'+input_file,sheet_name="solar")
    solardata['date'] = solardata.时间.str.split(" ",expand = True)[0]
    solardata['time'] = solardata.时间.str.split(" ",expand = True)[1]
    solari = solardata[solardata.date == datei].copy()
    solar_mean = solari["SOLAR_MI(W/m2)"].mean()
    ec_rate = round(solar_mean/cleanskysolar,3)
    f.writelines("   "+str(ec_rate))
else:
    ec_rate = os.getenv("EC_RATE")
    f.writelines("   "+str(ec_rate))

#f.writelines("   "+str(model_unc))
#f.writelines("   "+str(obs_unc))
f.close()
#print(julday)


exit()
