import pandas as pd
import numpy as np
import os
import datetime
import warnings
warnings.filterwarnings("ignore")

datei = os.getenv("DATE")
data_wd = os.getenv("DATA_DIR")
input_file = os.getenv("INPUT_FILE")
avocrate = float(os.getenv("AVOC_RATE"))
bvocrate = float(os.getenv("BVOC_RATE"))
noxrate = float(os.getenv("NOx_RATE"))
corate = float(os.getenv("CO_RATE"))
output_wd = "./model_data"

print(datei)
year = int(datei[0:4])
month = int(datei[5:7])
day = int(datei[8:10])
today = datetime.date(year,month,day)
# for voc
vocdata = pd.read_excel(data_wd+'/'+input_file,sheet_name="voc")
vocdata['date'] = vocdata.时间.str.split(" ",expand = True)[0]
vocdata['time'] = vocdata.时间.str.split(" ",expand = True)[1]
vocdata['异戊二烯'] = vocdata['异戊二烯']*bvocrate/avocrate
#vocdata = vocdata.fillna(9999)

# for others gas
gcdata = pd.read_excel(data_wd+'/'+input_file,sheet_name="cmdata")
gcdata['date'] = vocdata.时间.str.split(" ",expand = True)[0]
gcdata['time'] = vocdata.时间.str.split(" ",expand = True)[1]
gcdata["NO"]  = gcdata["NO"]*noxrate
gcdata["NO2"] = gcdata["NO2"]*noxrate
gcdata["CO"]  = gcdata["CO"]*corate
#gcdata = gcdata.fillna(999)

CH2MCM = pd.read_csv("CH2MCM.csv")
CH2MCM = CH2MCM.dropna()
CH2MCM.index = range(CH2MCM.shape[0])
#CH2MCM["MCMID"] = CH2MCM["MCMID"].astype("int")

voci = vocdata[vocdata.date == datei].copy()
gci = gcdata[gcdata.date == datei].copy()
for i in range(24):
    voctimei = pd.DataFrame(voci.iloc[i,2:vocdata.shape[1]-2].copy())*avocrate
    voctimei = voctimei.fillna(9999)
    voctimei.columns = ["value"]
    output = CH2MCM.merge(voctimei,left_on="CHname",right_on=voctimei.index)[["MCMvar","value"]]
    #print(voctimei)
    gctimei = pd.DataFrame(gci.iloc[i,2:gcdata.shape[1]-2].copy())
    gctimei = gctimei.fillna(9999)
    gctimei.columns = ["value"]
    output2 = CH2MCM.merge(gctimei,left_on="CHname",right_on=gctimei.index)[["MCMvar","value"]]
    output = output.append(output2)
    output.index = range(output.shape[0])
    #output.columns = [output.shape[0],'','']
    output.to_csv(output_wd+'/'+"CONCINP_"+str(i*3600).zfill(6)+".txt",index = False,sep = " ",header = None)

i = 0    
delta = datetime.timedelta(days = 1)
tomorrow = today + delta
tomorrow =  tomorrow.strftime("%Y-%m-%d")
voci = vocdata[vocdata.date == tomorrow].copy()
gci = gcdata[gcdata.date == tomorrow].copy()
voctimei = pd.DataFrame(voci.iloc[i,2:vocdata.shape[1]-2].copy())*avocrate
voctimei = voctimei.fillna(9999)
voctimei.columns = ["value"]
output = CH2MCM.merge(voctimei,left_on="CHname",right_on=voctimei.index)[["MCMvar","value"]]
gctimei = pd.DataFrame(gci.iloc[i,2:gcdata.shape[1]-2].copy())
gctimei = gctimei.fillna(9999)
gctimei.columns = ["value"]
output2 = CH2MCM.merge(gctimei,left_on="CHname",right_on=gctimei.index)[["MCMvar","value"]]
output = output.append(output2)
output.index = range(output.shape[0])
#output.columns = [output.shape[0],'','']
output.to_csv(output_wd+'/'+"CONCINP_"+str(24*3600).zfill(6)+".txt",index = False,sep = " ",header = None)


#for unrate
unrate = pd.read_excel(data_wd+'/'+input_file,sheet_name="unrate")
unrate['date'] = unrate.时间.str.split(" ",expand = True)[0]
unrate['time'] = unrate.时间.str.split(" ",expand = True)[1]
unrate = unrate[unrate.date == datei].copy()
for i in range(24):
    unratetimei = pd.DataFrame(unrate.iloc[i,2:unrate.shape[1]-2].copy())
    unratetimei = unratetimei.fillna(9999)
    unratetimei.columns = ["value"]
    routput = CH2MCM.merge(unratetimei,left_on="CHname",right_on=unratetimei.index)[["MCMvar","value"]]
    #output.columns = [output.shape[0],'','']
    routput.to_csv(output_wd+'/'+"OTHRATE_"+str(i*3600).zfill(6)+".txt",index = False,sep = " ",header = None)

#for emissions
emisrate = pd.read_excel(data_wd+'/'+input_file,sheet_name="emisrate")
emisrate['date'] = emisrate.时间.str.split(" ",expand = True)[0]
emisrate['time'] = emisrate.时间.str.split(" ",expand = True)[1]
emisrate = emisrate[emisrate.date == datei].copy()
for i in range(24):
    emisratetimei = pd.DataFrame(emisrate.iloc[i,2:emisrate.shape[1]-2].copy())
    emisratetimei = emisratetimei.fillna(9999)
    emisratetimei.columns = ["value"]
    routput = CH2MCM.merge(emisratetimei,left_on="CHname",right_on=emisratetimei.index)[["MCMvar","value"]]
    #output.columns = [output.shape[0],'','']
    routput.to_csv(output_wd+'/'+"EMIS_"+str(i*3600).zfill(6)+".txt",index = False,sep = " ",header = None)

    
#Meto
metodata = pd.read_excel(data_wd+'/'+input_file,sheet_name="meto")
metodata['date'] = metodata.时间.str.split(" ",expand = True)[0]
metodata['time'] = metodata.时间.str.split(" ",expand = True)[1]
metoi = metodata[metodata.date == datei].copy()
# PRES
pres = metoi.PRES.copy()
pres = pres.fillna(pres.mean())
p = pd.DataFrame()
p['Time'] = range(24)
p["PRES_kPa"] = pres.values
p.to_csv(output_wd+'/'+"PRES_input.txt",index = False,sep = " ")
# RH
rh = metoi.RH.copy()
rh = rh.fillna(rh.mean())
r = pd.DataFrame()
r['Time'] = range(24)
r["RH_100"] = rh.values
r.to_csv(output_wd+'/'+"RH_input.txt",index = False,sep = " ")
#TEMP
temp = metoi.TEMP.copy()
temp = temp.fillna(temp.mean())
t = pd.DataFrame()
t['Time'] = range(24)
t["TEMP"] = temp.values
t.to_csv(output_wd+'/'+"TEMP_input.txt",index = False,sep = " ")
# BLH
try:
    blh = metoi.BLH.copy()
    blh = blh.fillna(blh.mean())
    bh = pd.DataFrame()
    bh['Time'] = range(24)
    bh["BLH_m"] = blh.values
    bh.to_csv(output_wd+'/'+"BLH.txt",index = False,sep = " ")
except:
    pass
#Jvalues
try:
    Jdata = pd.read_excel(data_wd+'/'+input_file,sheet_name="Jvalues")
except:
    exit()
Jdata['date'] = Jdata.时间.str.split(" ",expand = True)[0]
Jdata['time'] = Jdata.时间.str.split(" ",expand = True)[1]
Jdatai = Jdata[Jdata.date == datei].copy()
Jdatai.index = range(24)
#print(Jdatai.shape)
for i in range(24):
    Jtimei = pd.DataFrame(Jdatai.iloc[i,2:Jdatai.shape[1]-2].copy())
    #print(Jtimei)
    Jtimei = Jtimei.fillna(9999)
    Jtimei.index = Jdatai.columns[2:Jdatai.shape[1]-2]
    Joutput = pd.DataFrame(columns = ['j'],index = Jtimei.index)
    for j in Jtimei.index:
        Joutput.loc[j,'j'] = "%E"%Jtimei.loc[j,i]

    Joutput.to_csv(output_wd+'/'+"Jvaluesobs_"+str(i).zfill(2)+".txt",header = None,sep = " ")

exit()
