import pandas as pd
import numpy as np
import datetime

wd         = "D:/study/paper/拉萨/ROMAC_result/QGS_AC/output"
filehead   = "CHEMLOSS"
startdate  = [2022,7,8]
enddate    = [2022,7,30]
classfile  = pd.read_excel("classfile_HCHOloss.xlsx")
spec       = "HCHO"
outputfile = "HCHO_chemloss.xlsx"

def set_daterange(x,y,split = ''):
    begin = datetime.date(x[0],x[1],x[2])
    end = datetime.date(y[0],y[1],y[2])
    d = begin
    delta = datetime.timedelta(days=1)
    date_set = pd.Series([],dtype='str')
    i = 1
    while d <= end:
        date_set[i] = d.strftime("%Y"+split+"%m"+split+"%d")
        d += delta
        i +=1
    return(date_set)
datelist = set_daterange(startdate,enddate,split="-")

output = pd.DataFrame(data = 0.0, index=range(datelist.shape[0]*25),columns=classfile["class"].drop_duplicates().dropna().values,dtype="float64")
output["others"] = 0.0
output["date"] = np.nan
output["time"] = np.nan
k = -1

for datex in datelist:
    chemfile = open(wd+"/"+filehead+"_"+datex+".txt",mode = "r") 
    specname = ""

    inspec = False
    finish = False
    while finish == False:
        try:
            char = chemfile.readline()
        except:
            finish = True
        try:
            char0 = char.split()[0]
        except:
            finish = True
        indata = True

        if specname == spec:
            print("Date = "+datex+" Time = "+str(timefloat)+" "+specname)
            inspec = True
        else:
            inspec = False

        if char0 == "Time":
            timefloat = float(char.split()[3])
            k+=1
            output.loc[k,"date"] = datex
            output.loc[k,"time"] = timefloat
            indata = False
        else:
            pass
        if char0 == "Variables":
            specname = char.split()[2]
            indata = False
        else:
            pass

        if (inspec) & (indata):
            try:
                reacid = int(char.split()[0])
            except:
                finish = True
            try:
                rate   = float(char.split()[1])
            except:
                rate   = 0.0

            classname = classfile[classfile["index"] == reacid]["class"].values[0]
            if pd.isna(classname):
                classname = "others"
            else:
                pass
            output.loc[k,classname] = output.loc[k,classname] + rate
            print("R"+str(reacid)+" = "+str(rate)+" ppbv/s") 
    chemfile.close()
    
output.to_excel(outputfile)