import pandas as pd
import numpy as np
import datetime

def dataselect(DATA_DIR, INPUT_FILE, startdate, enddate):
    output_dir = DATA_DIR
    input_file = INPUT_FILE
    def set_daterange(x,y):
        begin = datetime.date(x[0],x[1],x[2])
        end = datetime.date(y[0],y[1],y[2])
        delta = datetime.timedelta(days=1)
        begin = begin
        end   = end
        d = begin
        date_set = pd.Series([],dtype='str')
        i = 1
        while d <= end:
            date_set[i] = d.strftime("%Y-%m-%d")
            d += delta
            i +=1
        return(date_set)

    datelist = set_daterange(startdate,enddate)

    with pd.ExcelWriter(output_dir+'/'+input_file.split('.')[0]+".s.xlsx") as writer:
        for sheetx in ["voc","cmdata","meto","solar","emisrate","Jvalues","unrate"]:
            datax = pd.read_excel(DATA_DIR+"/"+INPUT_FILE,sheet_name=sheetx)
            datax["date"] = datax.时间.str.split(" ",expand = True)[0]
            datax = datax[datax.date.isin(datelist)]
            datax = datax.drop("date",axis = 1)
            datax.to_excel(writer,sheet_name = sheetx,index = False,header = True)
    return None
        
if __name__ == "__main__":
    DATA_DIR = "./UserData/"
    INPUT_FILE = "ROMACINPUT0000.xlsx"
    startdate  = [2023,9,1]
    enddate   = [2023,9,5]
    dataselect(DATA_DIR, INPUT_FILE, startdate, enddate)
    exit()
    