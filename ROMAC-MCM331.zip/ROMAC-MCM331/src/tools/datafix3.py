import pandas as pd
import numpy as np
import os
import datetime
#datei = "2021-06-01"
#data_wd = os.getenv("DATA_DIR")
data_wd = "../UserData/辽宁/"
output_wd = data_wd
#input_file = os.getenv("INPUT_FILE")
input_file   = "ROMACINPUT20190101.xlsx"

# for voc
vocdata = pd.read_excel(data_wd+'/'+input_file,sheet_name="voc")
vocdata['date'] = vocdata.时间.str.split(" ",expand = True)[0]
vocdata['time'] = vocdata.时间.str.split(" ",expand = True)[1]

#datafix
startcol = 2
endcol = vocdata.shape[1]-2
vocdata2 = vocdata.copy()
for i in range(startcol,endcol):
    for j in range(vocdata.shape[0]):
        if (pd.isna(vocdata2.iloc[j,i])) | (vocdata2.iloc[j,i] == 0):
            if (j>=4) & (j <= vocdata.shape[0]-4):
                meanvalue = vocdata2.iloc[range((j-4),j+4),i].mean()
            else:
                meanvalue = vocdata[vocdata.time == vocdata.iloc[j,vocdata.shape[1]-1]].iloc[:,i].mean()
            if pd.isna(meanvalue):
                meanvalue = vocdata[vocdata.time == vocdata.iloc[j,vocdata.shape[1]-1]].iloc[:,i].mean()
            else:
                pass
            vocdata2.iloc[j,i] = meanvalue
        else:
            pass
#vocdata2.iloc[:,:vocdata2.shape[1]-2].to_excel("VOC.datafix.xlsx",index = False)
vocfix = vocdata2.iloc[:,:vocdata2.shape[1]-2].copy()

# for cmdata
vocdata = pd.read_excel(data_wd+'/'+input_file,sheet_name="cmdata")
vocdata['date'] = vocdata.时间.str.split(" ",expand = True)[0]
vocdata['time'] = vocdata.时间.str.split(" ",expand = True)[1]

#datafix
startcol = 2
endcol = vocdata.shape[1]-2
vocdata2 = vocdata.copy()
for i in range(startcol,endcol):
    for j in range(vocdata.shape[0]):
        if (pd.isna(vocdata2.iloc[j,i])) | (vocdata2.iloc[j,i] == 0):
            if (j>=4) & (j <= vocdata.shape[0]-4):
                meanvalue = vocdata2.iloc[range((j-4),j+4),i].mean()
            else:
                meanvalue = vocdata[vocdata.time == vocdata.iloc[j,vocdata.shape[1]-1]].iloc[:,i].mean()
            if pd.isna(meanvalue):
                meanvalue = vocdata[vocdata.time == vocdata.iloc[j,vocdata.shape[1]-1]].iloc[:,i].mean()
            else:
                pass
            vocdata2.iloc[j,i] = meanvalue
        else:
            pass
#vocdata2.iloc[:,:vocdata2.shape[1]-2].to_excel("CM.datafix.xlsx",index = False)
cmfix = vocdata2.iloc[:,:vocdata2.shape[1]-2].copy()

# for meto
vocdata = pd.read_excel(data_wd+'/'+input_file,sheet_name="meto")
vocdata['date'] = vocdata.时间.str.split(" ",expand = True)[0]
vocdata['time'] = vocdata.时间.str.split(" ",expand = True)[1]

#datafix
startcol = 2
endcol = vocdata.shape[1]-2
vocdata2 = vocdata.copy()
for i in range(startcol,endcol):
    for j in range(vocdata.shape[0]):
        if (pd.isna(vocdata2.iloc[j,i])) | (vocdata2.iloc[j,i] == 0):
            if (j>=4) & (j <= vocdata.shape[0]-4):
                meanvalue = vocdata2.iloc[range((j-4),j+4),i].mean()
            else:
                meanvalue = vocdata[vocdata.time == vocdata.iloc[j,vocdata.shape[1]-1]].iloc[:,i].mean()
            if pd.isna(meanvalue):
                meanvalue = vocdata[vocdata.time == vocdata.iloc[j,vocdata.shape[1]-1]].iloc[:,i].mean()
            else:
                pass
            vocdata2.iloc[j,i] = meanvalue
        else:
            pass
#vocdata2.iloc[:,:vocdata2.shape[1]-2].to_excel("METO.datafix.xlsx",index = False)
metofix = vocdata2.iloc[:,:vocdata2.shape[1]-2].copy()

# for solar
vocdata = pd.read_excel(data_wd+'/'+input_file,sheet_name="solar")
vocdata['date'] = vocdata.时间.str.split(" ",expand = True)[0]
vocdata['time'] = vocdata.时间.str.split(" ",expand = True)[1]

#datafix
startcol = 2
endcol = vocdata.shape[1]-2
vocdata2 = vocdata.copy()
for i in range(startcol,endcol):
    for j in range(vocdata.shape[0]):
        if (pd.isna(vocdata2.iloc[j,i])) | (vocdata2.iloc[j,i] == 0):
            if (j>=4) & (j <= vocdata.shape[0]-4):
                meanvalue = vocdata2.iloc[range((j-4),j+4),i].mean()
            else:
                meanvalue = vocdata[vocdata.time == vocdata.iloc[j,vocdata.shape[1]-1]].iloc[:,i].mean()
            if pd.isna(meanvalue):
                meanvalue = vocdata[vocdata.time == vocdata.iloc[j,vocdata.shape[1]-1]].iloc[:,i].mean()
            else:
                pass
            vocdata2.iloc[j,i] = meanvalue
        else:
            pass
#vocdata2.iloc[:,:vocdata2.shape[1]-2].to_excel("SOLAR.datafix.xlsx",index = False)
solarfix = vocdata2.iloc[:,:vocdata2.shape[1]-2].copy()

Jvalues = pd.read_excel(data_wd+'/'+input_file,sheet_name="Jvalues")
unrate = pd.read_excel(data_wd+'/'+input_file,sheet_name="unrate")
emisrate =  pd.read_excel(data_wd+'/'+input_file,sheet_name="emisrate")


def adddate(vocfix):
    lastdate = vocfix.iloc[-1,1]
    yearl = int(lastdate.split("-")[0])
    monthl = int(lastdate.split("-")[1])
    dayl = int(lastdate.split("-")[2].split(" ")[0])
    lastdate = (datetime.datetime(yearl,monthl,dayl)+datetime.timedelta(days = 1)).strftime("%Y-%m-%d") + " 00"
    lastdata = vocfix.iloc[-1,:].copy()
    lastdata["时间"] = lastdate
    lastdata = pd.DataFrame(lastdata).T
    lastdata.index = ["addd"]
    vocfix = pd.concat([vocfix,lastdata])
    return(vocfix)
    
vocfix   = adddate(vocfix)
cmfix    = adddate(cmfix)
metofix  = adddate(metofix)
solarfix = adddate(solarfix)
emisrate = adddate(emisrate)
Jvalues  = adddate(Jvalues)
unrate   = adddate(unrate)

with pd.ExcelWriter(output_wd+'/'+input_file.split('.')[0]+".fix2.xlsx") as writer:
    vocfix.to_excel(writer,sheet_name = "voc",index = False,header = True)
    cmfix.to_excel(writer,sheet_name = "cmdata",index = False,header = True)
    metofix.to_excel(writer,sheet_name = "meto",index = False,header = True)
    solarfix.to_excel(writer,sheet_name = "solar",index = False,header = True)
    emisrate.to_excel(writer,sheet_name = "emisrate",index = False,header = True)
    Jvalues.to_excel(writer,sheet_name = "Jvalues",index = False,header = True)
    unrate.to_excel(writer,sheet_name = "unrate",index = False,header = True)
exit()

