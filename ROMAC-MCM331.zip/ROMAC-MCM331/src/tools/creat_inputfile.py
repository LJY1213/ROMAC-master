import pandas as pd
import numpy as np
import datetime

startdate = [2025,1,1]
enddate = [2025,4,19]
sitename = "Liaoning"
output_wd = "./"
def set_daterange(x,y):
    begin = datetime.date(x[0],x[1],x[2])
    end = datetime.date(y[0],y[1],y[2])
    delta = datetime.timedelta(days=1)
    begin = begin
    end   = end
    d = begin
    date_set = pd.Series([],dtype='str')
    i = 1
    while d <= end:
        date_set[i] = d.strftime("%Y-%m-%d")
        d += delta
        i +=1
    return(date_set)
datelist = set_daterange(startdate,enddate)

emptydata = pd.DataFrame(index=range(datelist.shape[0]*24),columns=["站点","时间"])
emptydata["站点"] = sitename
k = 0
for datei in datelist:
    for h in range(24):
        strdatetime = datei + " " + str(h).zfill(2)
        emptydata.loc[k,"时间"] = strdatetime
        k+=1
        
Jdata = emptydata.copy()
Jdata["SOLAR_MI(W/m2)"] = np.nan
with pd.ExcelWriter(output_wd+"/ROMACINPUT"+str(startdate[0]).zfill(4)+str(startdate[1]).zfill(2)+str(startdate[2]).zfill(2)+".xlsx") as writer:
    emptydata.to_excel(writer,sheet_name = "voc",index = False,header = True)
    emptydata.to_excel(writer,sheet_name = "cmdata",index = False,header = True)
    emptydata.to_excel(writer,sheet_name = "meto",index = False,header = True)
    Jdata.to_excel(writer,sheet_name = "solar",index = False,header = True)
    emptydata.to_excel(writer,sheet_name = "emisrate",index = False,header = True)
    emptydata.to_excel(writer,sheet_name = "Jvalues",index = False,header = True)
    emptydata.to_excel(writer,sheet_name = "unrate",index = False,header = True)
    
exit()
