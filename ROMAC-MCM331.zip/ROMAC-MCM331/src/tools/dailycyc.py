import pandas as pd
import numpy as np

#datei = "2021-06-01"
data_wd = "../UserData/天井山"
output_dir = data_wd
input_file = "ROMACINPUT20201013.fix3-BASE.xlsx"

# for voc
vocdata = pd.read_excel(data_wd+'/'+input_file,sheet_name="voc")
vocdata['date'] = vocdata.时间.str.split(" ",expand = True)[0]
vocdata['time'] = vocdata.时间.str.split(" ",expand = True)[1]

#datafix
startcol = 2
endcol = vocdata.shape[1]-2
vocdata2 = vocdata.iloc[:,startcol:vocdata.shape[1]-2].copy()
vocdata2['time'] = vocdata.time
vocdata2 = vocdata2.groupby("time").mean()
vocdata2.insert(0,"时间",vocdata.loc[range(24),'时间'].values)
vocdata2.insert(0,"站点",vocdata.loc[range(24),'站点'].values)
vocfix = vocdata2.iloc[:,:vocdata2.shape[1]].copy()

# for cmdata
vocdata = pd.read_excel(data_wd+'/'+input_file,sheet_name="cmdata")
vocdata['date'] = vocdata.时间.str.split(" ",expand = True)[0]
vocdata['time'] = vocdata.时间.str.split(" ",expand = True)[1]

#datafix
startcol = 2
endcol = vocdata.shape[1]-2
vocdata2 = vocdata.iloc[:,startcol:vocdata.shape[1]-2].copy()
vocdata2['time'] = vocdata.time
vocdata2 = vocdata2.groupby("time").mean()
vocdata2.insert(0,"时间",vocdata.loc[range(24),'时间'].values)
vocdata2.insert(0,"站点",vocdata.loc[range(24),'站点'].values)
cmfix = vocdata2.iloc[:,:vocdata2.shape[1]].copy()

# for meto
vocdata = pd.read_excel(data_wd+'/'+input_file,sheet_name="meto")
vocdata['date'] = vocdata.时间.str.split(" ",expand = True)[0]
vocdata['time'] = vocdata.时间.str.split(" ",expand = True)[1]

#datafix
startcol = 2
endcol = vocdata.shape[1]-2
vocdata2 = vocdata.iloc[:,startcol:vocdata.shape[1]-2].copy()
vocdata2['time'] = vocdata.time
vocdata2 = vocdata2.groupby("time").mean()
vocdata2.insert(0,"时间",vocdata.loc[range(24),'时间'].values)
vocdata2.insert(0,"站点",vocdata.loc[range(24),'站点'].values)
metofix = vocdata2.iloc[:,:vocdata2.shape[1]].copy()

# for solar
#vocdata = pd.read_excel(data_wd+'/'+input_file,sheet_name="solar")
#vocdata['date'] = vocdata.时间.str.split(" ",expand = True)[0]
#vocdata['time'] = vocdata.时间.str.split(" ",expand = True)[1]

#datafix
startcol = 2
endcol = vocdata.shape[1]-2
vocdata2 = vocdata.iloc[:,startcol:vocdata.shape[1]-2].copy()
vocdata2['time'] = vocdata.time
vocdata2 = vocdata2.groupby("time").mean()
vocdata2.insert(0,"时间",vocdata.loc[range(24),'时间'].values)
vocdata2.insert(0,"站点",vocdata.loc[range(24),'站点'].values)
solarfix = vocdata2.iloc[:,:vocdata2.shape[1]].copy()

with pd.ExcelWriter(output_dir+'/'+input_file.split('.')[0]+".dailycyc.xlsx") as writer:
    vocfix.to_excel(writer,sheet_name = "voc",index = False,header = True)
    cmfix.to_excel(writer,sheet_name = "cmdata",index = False,header = True)
    metofix.to_excel(writer,sheet_name = "meto",index = False,header = True)
    solarfix.to_excel(writer,sheet_name = "solar",index = False,header = True)
exit()

