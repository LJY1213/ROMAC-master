import pandas as pd
import numpy as np

def set_daterange(x,y):
    import datetime
    begin = datetime.date(x[0],x[1],x[2])
    end = datetime.date(y[0],y[1],y[2])
    d = begin
    delta = datetime.timedelta(days=1)
    date_set = pd.Series([],dtype='str')
    i = 1
    while d <= end:
        date_set[i] = d.strftime("%Y-%m-%d")
        d += delta
        i +=1
    return(date_set)

startdate = [2023,10,3]
enddate = [2023,10,5]
#massnum = 2
data_dir = "../output/"
output_dir = "../output/"
datelist = set_daterange(startdate,enddate)

#output = pd.DataFrame(columns = range(massnum+2),dtype = "float64")
for datei in datelist:        
    #f = open(data_dir+'/'+datei+'_CONC_molc.txt')
    f = open(data_dir+'/'+datei+'_dopt.txt')
    data = pd.DataFrame(columns = f.readline().split(),dtype = "float64")
    massnum = data.shape[1]-2
    if (datei == datelist.iloc[0]):
        output = pd.DataFrame(columns = range(massnum+3),dtype = "float64")
    else:
        pass
    i = 0
    #for i in range(24):
    #    data.loc[i,:] = f.readline().split()
    while True:
        try :
            data.loc[i,:] = f.readline().split()
            i = i+1
        except:
            break 
    data["Date"] = datei
    output.columns = data.columns
    output = output.append(data)
    f.close()
for k in range(massnum+1):
    output.iloc[:,k] = output.iloc[:,k].apply(pd.to_numeric)

output.index = range(output.shape[0])
output = output.dropna()
output.to_excel(output_dir+"/DOPT.xlsx")

exit()
