NAvalue = 6.02e23
rvalue = 8.314472e6
PRES = 101325
TEMP = 298.15
def ppbv2mc(x):
	return(x*(1.0e-9)*PRES*NAvalue/(rvalue*TEMP))
def mc2ppbv(x):
	return(x*rvalue*TEMP/(PRES*NAvalue*(1.0e-9)))
