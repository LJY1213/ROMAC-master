import pandas as pd
import numpy as np

def set_daterange(x,y):
    import datetime
    begin = datetime.date(x[0],x[1],x[2])
    end = datetime.date(y[0],y[1],y[2])
    d = begin
    delta = datetime.timedelta(days=1)
    date_set = pd.Series([],dtype='str')
    i = 1
    while d <= end:
        date_set[i] = d.strftime("%Y-%m-%d")
        d += delta
        i +=1
    return(date_set)

startdate = [2021,6,1]
enddate = [2021,6,27]
masslist = ["PAN"]
data_dir = "../output"
output_dir = "../output"
datelist = set_daterange(startdate,enddate)
for massi in masslist:
    output = pd.DataFrame(columns = ["","",""],dtype = "float64")
    for datei in datelist:
        data = pd.DataFrame(columns = ["",""],dtype = "float64")
        f = open(data_dir+'/'+datei+'_CONC_'+massi+"_ppbv.txt")
        data.columns = f.readline().split()
        for i in range(24):
            data.loc[i,:] = f.readline().split()
        data["Date"] = datei
        output.columns = data.columns
        output = output.append(data)
    output.iloc[:,0] = output.iloc[:,0].apply(pd.to_numeric)
    output.iloc[:,1] = output.iloc[:,1].apply(pd.to_numeric)
    output.index = range(output.shape[0])
    output.to_excel(output_dir+"/"+massi+"_CONC.xlsx")

for massi in masslist:
    output = pd.DataFrame(columns = ["","",""],dtype = "float64")
    for datei in datelist:
        data = pd.DataFrame(columns = ["",""],dtype = "float64")
        f = open(data_dir+'/'+datei+'_ACONC_'+massi+"_ppbv.txt")
        data.columns = f.readline().split()
        for i in range(24):
            data.loc[i,:] = f.readline().split()
        data["Date"] = datei
        output.columns = data.columns
        output = output.append(data)
    output.iloc[:,0] = output.iloc[:,0].apply(pd.to_numeric)
    output.iloc[:,1] = output.iloc[:,1].apply(pd.to_numeric)
    output.index = range(output.shape[0])
    output.to_excel(output_dir+"/"+massi+"_ACONC.xlsx")
exit()
