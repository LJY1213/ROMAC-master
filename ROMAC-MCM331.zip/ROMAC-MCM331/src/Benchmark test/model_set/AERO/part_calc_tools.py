import pybel
import diff_vol_est
import pandas as pd
import sys
import os

cwd = os.getcwd()
sys.path.insert(1, (cwd+'/umansysprop'))
from umansysprop import boiling_points
from umansysprop import vapour_pressures
from umansysprop import liquid_densities
#import liquid_densities
data = pd.read_csv("SpecSMILE")
for i in range(data.shape[0]):
    pybel_obj = pybel.readstring('smi',data.iloc[i,1])
    #print(pybel_obj)
    a = diff_vol_est.diff_vol_est([pybel_obj])
    dens = liquid_densities.girolami(pybel_obj)
    MW = pybel_obj.molwt
    print(str(data.iloc[i,0]))
    print("diff_vol = " + str(a[0]))
    print("dens = " + str(dens*1e3) + " kg/m^3")
    print("MW = " + str(MW) + " g/mol")
