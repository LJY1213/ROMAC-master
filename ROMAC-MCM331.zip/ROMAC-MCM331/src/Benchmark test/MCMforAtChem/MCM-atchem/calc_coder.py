import pandas as pd
import numpy as np

isa = pd.read_csv("ISA.txt",sep = " ",header = None)

maxeqn = isa[0].max()
maxspec = isa[1].max()

maxorder = pd.DataFrame(0,columns=range(1,maxspec+1),index=range(1,maxeqn+1),dtype="int")

for isax in isa.index:
    eqnx = isa.loc[isax,0]
    specx = isa.loc[isax,1]
    maxorder.loc[eqnx,specx] = maxorder.loc[eqnx,specx]+1
    
maxorder.max().to_csv("spec_maxorder.txt",sep = " ",header = None)  

reac = np.where(maxorder>1)[0]
spec = np.where(maxorder>1)[1]
sp_maxorder = pd.DataFrame(0,columns=["reac_num","spec_num","order"],index = range(len(spec)),dtype="int")

for x in range(len(reac)):
    sp_maxorder.loc[x,"reac_num"] = reac[x]+1
    sp_maxorder.loc[x,"spec_num"] = spec[x]+1
    sp_maxorder.loc[x,"order"] = maxorder.iloc[reac[x],spec[x]]
    
sp_maxorder.to_csv("sp_order.txt",index = False,header=None,sep = " ")