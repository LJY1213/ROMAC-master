import pandas as pd
import numpy as np
import os
import datetime

datei = os.getenv("DATE")
data_wd = os.getenv("DATA_DIR")
input_file = os.getenv("INPUT_FILE")
vocrate = float(os.getenv("VOC_RATE"))
output_wd = "./model_data"

print(datei)
# for voc
vocdata = pd.read_excel(data_wd+'/'+input_file,sheet_name="voc")
vocdata['date'] = vocdata.时间.str.split(" ",expand = True)[0]
vocdata['time'] = vocdata.时间.str.split(" ",expand = True)[1]
#vocdata = vocdata.fillna(999)

# for others gas
gcdata = pd.read_excel(data_wd+'/'+input_file,sheet_name="cmdata")
gcdata['date'] = vocdata.时间.str.split(" ",expand = True)[0]
gcdata['time'] = vocdata.时间.str.split(" ",expand = True)[1]
#gcdata = gcdata.fillna(999)

CH2MCM = pd.read_csv("CH2MCM.csv")
CH2MCM = CH2MCM.dropna()
CH2MCM.index = range(CH2MCM.shape[0])
CH2MCM["MCMID"] = CH2MCM["MCMID"].astype("int")

voci = vocdata[vocdata.date == datei].copy()
gci = gcdata[gcdata.date == datei].copy()
for i in range(24):
    voctimei = pd.DataFrame(voci.iloc[i,2:vocdata.shape[1]-2].copy())*vocrate
    voctimei = voctimei.fillna(9999)
    voctimei.columns = ["value"]
    output = CH2MCM.merge(voctimei,left_on="CHname",right_on=voctimei.index)[["MCMID","MCMvar","value"]]
    gctimei = pd.DataFrame(gci.iloc[i,2:gcdata.shape[1]-2].copy())
    gctimei = gctimei.fillna(9999)
    gctimei.columns = ["value"]
    output2 = CH2MCM.merge(gctimei,left_on="CHname",right_on=gctimei.index)[["MCMID","MCMvar","value"]]
    output = output.append(output2)
    output.index = range(output.shape[0])
    output.columns = [output.shape[0],'','']
    output.to_csv(output_wd+'/'+"GCobs_"+str(i).zfill(2)+".txt",index = False,sep = " ")

#Meto
metodata = pd.read_excel(data_wd+'/'+input_file,sheet_name="meto")
metodata['date'] = metodata.时间.str.split(" ",expand = True)[0]
metodata['time'] = metodata.时间.str.split(" ",expand = True)[1]
metoi = metodata[metodata.date == datei].copy()
# PRES
pres = metoi.PRES.copy()
pres = pres.fillna(pres.mean())
p = pd.DataFrame()
p['Time'] = range(24)
p["PRES_kPa"] = pres.values
p.to_csv(output_wd+'/'+"PRES_input.txt",index = False,sep = " ")
# RH
rh = metoi.RH.copy()
rh = rh.fillna(rh.mean())
r = pd.DataFrame()
r['Time'] = range(24)
r["RH_100"] = rh.values
r.to_csv(output_wd+'/'+"RH_input.txt",index = False,sep = " ")
#TEMP
temp = metoi.TEMP.copy()
temp = temp.fillna(temp.mean())
t = pd.DataFrame()
t['Time'] = range(24)
t["TEMP"] = temp.values
t.to_csv(output_wd+'/'+"TEMP_input.txt",index = False,sep = " ")

exit()
